﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Sensor super1, super2;
            SmokeSensor sub1, sub2;
            
            super1 = new Sensor("Sensor");
            sub1 = new SmokeSensor("Smoke", "Smoke Sensor");

            ////Rule 1
            //super2 = super1;
            ////Checks if an object is compatible with a given type. 
            //if (super2 is Sensor)
            //    Console.WriteLine("super2 is a Sensor");
            //else
            //    Console.WriteLine("super2 is not a Sensor");
            //if (super2 is SmokeSensor)
            //    Console.WriteLine("super2 is a SmokeSensor");
            //else
            //    Console.WriteLine("super2 is not a SmokeSensor");
            ////Gets the Type of the current instance.
            //Console.WriteLine("super2 is {0}", super2.GetType());

            ////Rule 2
            //sub2 = sub1;
            //if (sub2 is Sensor)
            //    Console.WriteLine("sub2 is a Sensor");
            //else
            //    Console.WriteLine("sub2 is not a Sensor");
            //if (sub2 is SmokeSensor)
            //    Console.WriteLine("sub2 is a SmokeSensor");
            //else
            //    Console.WriteLine("sub2 is not a SmokeSensor");
            //Console.WriteLine("sub2 is {0}", sub2.GetType());

            ////Rule 3
            //super2 = sub1;
            //if (super2 is Sensor)
            //    Console.WriteLine("super2 is a Sensor");
            //else
            //    Console.WriteLine("super2 is not a Sensor");
            //if (super2 is SmokeSensor)
            //    Console.WriteLine("super2 is a SmokeSensor");
            //else
            //    Console.WriteLine("super2 is not a SmokeSensor");
            //Console.WriteLine("super2 is {0}", super2.GetType());

            ////Rule 4.1
            //sub2 = super1;
            //if (sub2 is Sensor)
            //    Console.WriteLine("sub2 is a Sensor");
            //else
            //    Console.WriteLine("sub2 is not a Sensor");
            //if (sub2 is SmokeSensor)
            //    Console.WriteLine("sub2 is a SmokeSensor");
            //else
            //    Console.WriteLine("sub2 is not a SmokeSensor");
            //Console.WriteLine("sub2 is {0}", sub2.GetType());

            ////Rule 4.2
            //sub2 = (SmokeSensor)super1;
            //if (sub2 is Sensor)
            //    Console.WriteLine("sub2 is a Sensor");
            //else
            //    Console.WriteLine("sub2 is not a Sensor");
            //if (sub2 is SmokeSensor)
            //    Console.WriteLine("sub2 is a SmokeSensor");
            //else
            //    Console.WriteLine("sub2 is not a SmokeSensor");
            //Console.WriteLine("sub2 is {0}", sub2.GetType());

            ////Rule 4.3
            //sub2 = super1 as SmokeSensor;
            //if (sub2 is Sensor)
            //    Console.WriteLine("sub2 is a Sensor");
            //else
            //    Console.WriteLine("sub2 is not a Sensor");
            //if (sub2 is SmokeSensor)
            //    Console.WriteLine("sub2 is a SmokeSensor");
            //else
            //    Console.WriteLine("sub2 is not a SmokeSensor");
            //Console.WriteLine("sub2 is {0}", sub2.GetType());

            ////Rule 4.4
            //super2 = sub1;
            //sub2 = (SmokeSensor)super2;
            //if (sub2 is Sensor)
            //    Console.WriteLine("sub2 is a Sensor");
            //else
            //    Console.WriteLine("sub2 is not a Sensor");
            //if (sub2 is SmokeSensor)
            //    Console.WriteLine("sub2 is a SmokeSensor");
            //else
            //    Console.WriteLine("sub2 is not a SmokeSensor");
            //Console.WriteLine("sub2 is {0}", sub2.GetType());

            ////Polymoorphism 
            //Sensor[] sensors = new Sensor[2];

            //sensors[0] = new Sensor("Base Sensor");
            //sensors[1] = new SmokeSensor("Smoke", "Smoke Sensor");

            //sensors[0].ActionType();
            //sensors[1].ActionType();

            //if (sensors[0] is Sensor)
            //    Console.WriteLine("sensor[0] is a Sensor");
            //else
            //    Console.WriteLine("sensor[0] is not a Sensor");

            //if (sensors[0] is SmokeSensor)
            //    Console.WriteLine("sensor[0] is a SmokeSensor");
            //else
            //    Console.WriteLine("sensor[0] is not a SmokeSensor");

            //Console.WriteLine("sensor[0] refer to {0}", sensors[0].GetType());

            //if (sensors[1] is Sensor)
            //    Console.WriteLine("sensor[1] is a Sensor");
            //else
            //    Console.WriteLine("sensor[1] is not a Sensor");

            //if (sensors[1] is SmokeSensor)
            //    Console.WriteLine("sensor[1] is a SmokeSensor");
            //else
            //    Console.WriteLine("sensor[1] is not a SmokeSensor");

            //Console.WriteLine("sensor[1] refer to {0}", sensors[1].GetType());

            Console.ReadKey();

        }
    }
}
