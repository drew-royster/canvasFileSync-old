﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class Sensor
    {
        private string sensorName;

        public Sensor(string _name)
        {
            sensorName = _name;
        }

        public virtual void ActionType()
        {
            Console.WriteLine("Sensor Detect Nothing.");
        }
    }
}
