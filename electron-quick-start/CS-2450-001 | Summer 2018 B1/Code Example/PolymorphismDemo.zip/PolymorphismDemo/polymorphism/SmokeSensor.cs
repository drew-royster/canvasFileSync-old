﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PolymorphismDemo
{
    class SmokeSensor : Sensor
    {
        private string type;

        public SmokeSensor(string _type, string _name) : base(_name)
        {
            type = _type;
        }

        public override void ActionType ()
        {
            Console.WriteLine("Somke Sensor Detect Smoke.");
        }
    }
}
