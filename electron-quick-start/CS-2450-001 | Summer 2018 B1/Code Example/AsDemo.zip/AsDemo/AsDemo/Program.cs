﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AsDemo
{
    class csrefKeywordsOperators
    {
        class Base
        {
            public override string ToString()
            {
                return "Base";
            }
        }
        class Derived : Base
        { }

        class Program
        {
            static void Main()
            {

                Derived d = new Derived();

                //Base b = d as Base;
                Base b = (Base)d;
                //Base b = d;


                if (b != null)
                {
                    Console.WriteLine(b.ToString());
                }
                
                Base c = new Base();
                d = (Derived) c;
                //d = c as Derived;
                
                Console.ReadKey();

            }
        }
    }

}
