﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoupingDemo
{
    class Market
    {   
        Customers c = new Customers();

        public bool SearchID(ref int[] id, int key)
        {
            bool found = false;

            for (int i = 0; i < id.Length; i++)
            {
                if (id[i] == key)
                {
                    found = true;
                    id[i] = 0; //Content coupling
                }                                  
            }

            return found;
        }

        
        public void WhoistheFirsCustomer()
        {
            Console.WriteLine("The first customer is {0}", c.getFirstCustomer());
        }

        public void SetSeason (int season)
        {
            c.SeasonPreference(season);
        }
    }
}
