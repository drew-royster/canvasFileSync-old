﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoupingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //Content coupling
            Customers customers = new Customers();
            Market market = new Market();
            int [] ids = customers.getID();
            if ( market.SearchID(ref ids, 123) )
            {                
                foreach (int id in ids)
                    Console.WriteLine(" {0}", id);
            }

            //Stamp coupling 
            int[] ids1 = customers.getID();
            foreach (int id in ids1)
                Console.WriteLine(" {0}", id);

            //Common coupling
            Customers c1 = new Customers();
            Customers c2 = new Customers();
            c2.setPrice(200);
            Console.WriteLine("The price changed to {0}", c1.getPrice());

            //Data coupling
            market.WhoistheFirsCustomer();

            //Control coupling
            market.SetSeason(1);
            market.SetSeason(2);
            market.SetSeason(3);

            //External coupling
            //if customers and market write to file or database. 

            Console.ReadKey();
        }
    }
}
