﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CoupingDemo
{
    class Customers
    {
        private int[] customerID = new int[] {123, 456, 789};
        static int price = 100; //Common coupling

        public int getFirstCustomer()
        {
            return customerID[0]; //Data Coupling
        }

        public int[] getID ()
        {
            return customerID;//Stamp coupling
        }

        public void setID(int[] id)
        {
            customerID = id;
        }

        public void setPrice(int _price)
        {
            price = _price;
        }

        public int getPrice()
        {
            return price;
        }

        public void SeasonPreference(int season) //Control coupling
        {
            switch (season)
            {
                case 1:
                    Console.WriteLine("Summer");
                    break;
                case 2:
                    Console.WriteLine("Winter");
                    break;
                default:
                    Console.WriteLine("Spring or Fall");
                    break;
            }
        }

    }
}
