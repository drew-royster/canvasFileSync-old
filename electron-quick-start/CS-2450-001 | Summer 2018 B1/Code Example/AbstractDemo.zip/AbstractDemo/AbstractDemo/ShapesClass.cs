﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo
{
    abstract class ShapesClass
    {
        protected int side = 10;
        //private int side = 10;
        //public int side = 10;
        abstract public int Area();
    }
}
