﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AbstractDemo
{
    class Program
    {

        static void Main(string[] args)
        {
            Square sq = new Square();
            Console.WriteLine("The area is {0:d}", sq.Area());
            Console.ReadKey();
        }
    }
}
