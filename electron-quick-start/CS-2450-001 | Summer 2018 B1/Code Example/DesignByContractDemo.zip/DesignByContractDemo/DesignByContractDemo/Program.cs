﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DesignByContractDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Please input numerator:");
            int numerator = int.Parse(Console.ReadLine());
            Console.WriteLine("Please input denominator:");
            int denominator = int.Parse(Console.ReadLine());
            
            //(1)
            Division d = new Division(numerator, denominator);
            Console.WriteLine("(1) result = {0}", d.Divid());

            //(2)
            DicisionWithCheck dd = new DicisionWithCheck();
            Console.WriteLine("(2) result = {0}", dd.Divid());

            //(3)
            if (denominator == 0)
                Console.WriteLine("(3) Checked by client!!! denominator is 0, can not perform the calculation!!!");
            else
                Console.WriteLine("(3) result = {0}", d.Divid());
            
            //(4)
            if (denominator == 0)
                Console.WriteLine("(4) Checked by client!!! denominator is 0, can not perform the calculation!!!");
            else
                Console.WriteLine("(4) result = {0} ", dd.Divid());

            Console.ReadKey();
        }
    }

    class Division
    {
        protected static double numerator; 
        protected static double denominator;

        public Division (double _numerator, double _denominator)
        {
            numerator = _numerator;
            denominator = _denominator;
        }

        public virtual double Divid()
        {
            return numerator / denominator;
        }
    }

    class DicisionWithCheck : Division 
    { 
        public DicisionWithCheck () : base (numerator, denominator)
        {
        }

        public bool CheckZero (double denominator)
        { 
            Console.WriteLine("Checked by Server!!!");
            if (denominator == 0)
                return true;
            else
                return false;
        }

        public override double Divid()
        {
            if (CheckZero(denominator))
                return 99999;
            else
                return numerator / denominator;
        }

    }

}
