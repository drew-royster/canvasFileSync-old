﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace propertyHidingDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            DerivedClass d1 = new DerivedClass();
            
            d1.Name = "John";  // Derived class property
            Console.WriteLine("Name in the base class is: {0}", ((BaseClass)d1).Name);
            Console.WriteLine("Name in the derived class is: {0}", d1.Name);
            
            ((BaseClass)d1).Name = "Mary"; // Base class property
            Console.WriteLine("Name in the base class is: {0}", ((BaseClass)d1).Name);
            Console.WriteLine("Name in the derived class is: {0}", d1.Name);
            
            Console.ReadKey();
        }
    }
    public class BaseClass
    {
        //private string name;
        protected string name;
        public string Name
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
    }

    public class DerivedClass : BaseClass
    {
        //private string name;
        //private new string name;
        public new string Name   // Notice the use of the new modifier
        {
            get
            {
                return name;
            }
            set
            {
                name = value;
            }
        }
    }

}
