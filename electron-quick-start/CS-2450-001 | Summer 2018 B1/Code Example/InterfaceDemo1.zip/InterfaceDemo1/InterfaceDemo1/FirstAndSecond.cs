﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo1
{
    class FirstAndSecond: IFirst, ISecond
    {
        First first = new First();
        Second second = new Second();
        public void FirstMethod() { first.FirstMethod(); }
        public void SecondMethod() { second.SecondMethod(); } //how about comment this line?
    }

}
