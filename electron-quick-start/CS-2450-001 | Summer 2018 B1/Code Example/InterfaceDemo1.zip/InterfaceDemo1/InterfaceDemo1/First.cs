﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace InterfaceDemo1
{
    class First
    {
        public virtual void FirstMethod() { Console.WriteLine("First"); }
        //public void FirstMethod() { Console.WriteLine("First"); }
    }
}
