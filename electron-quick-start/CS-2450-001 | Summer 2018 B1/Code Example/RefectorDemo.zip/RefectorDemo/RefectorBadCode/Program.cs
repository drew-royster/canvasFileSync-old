﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace RefectorBadCode
{
    class Program
    {
        // some  class level constants
        const int HALVES = 50;
        const int QUARTERS = 25;
        const int DIMES = 10;
        const int NICKELS = 5;
        const int PENNIES = 1;

        static void Main()
        {
            int money, value, changeValue; 

            Console.WriteLine("I will make change for you.");
            Console.Write("Enter in an amount between 1 and 99: ");
            money = int.Parse(Console.ReadLine());

            Console.WriteLine("For {0} you get:", money);

            value = money / HALVES;
            changeValue = money % HALVES;
            Console.WriteLine("{0} halves", value);

            value = changeValue / QUARTERS;
            changeValue = changeValue % QUARTERS;
            Console.WriteLine("{0} quarters", value);

            value = changeValue / DIMES;
            changeValue = changeValue % DIMES;
            Console.WriteLine("{0} dimes", value);

            value = changeValue / NICKELS;
            changeValue = changeValue % NICKELS;
            Console.WriteLine("{0} nickels", value);

            value = changeValue / PENNIES;
            changeValue = changeValue % PENNIES;
            Console.WriteLine("{0} pennies\n", value);

            Console.ReadLine();
        }

        //static int ComputeChange(ref int changeValue, int coinValue)
        //{
        //    int value = changeValue / coinValue;
        //    changeValue = changeValue % coinValue;
        //    return value;
        //}

    }
}
