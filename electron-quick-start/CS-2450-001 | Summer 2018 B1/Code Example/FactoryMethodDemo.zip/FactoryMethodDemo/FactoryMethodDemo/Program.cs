﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FactoryMethodDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            IPhoneConcreteFactory factory = new IPhoneConcreteFactory();
            IProduct iPhone = factory.ProduceItem();
            Console.WriteLine("Name: {0}, Price: {1}", iPhone.GetName(), iPhone.GetPrice());
            Console.ReadKey();
        }      
    }

    public interface IProduct
    {
        string GetName();
        string SetPrice(double price);
        double GetPrice();
    }

    public class IPhone : IProduct
    {
        private double _price;
        #region IProduct Members

        public string GetName()
        {
            return "Apple TouchPad";
        }

        public string SetPrice(double price)
        {
            this._price = price;
            return "success";
        }

        public double GetPrice()
        {
            return _price;
        }
        #endregion
    }

    /* Almost same as Factory, just an additional exposure to do something with the created method */
    public abstract class ProductAbstractFactory
    {
        public abstract IProduct ProduceItem();

        public IProduct GetObject() // Implementation of Factory Method.
        {
            return this.ProduceItem();
        }
    }

    public class IPhoneConcreteFactory : ProductAbstractFactory
    {
        public override IProduct ProduceItem()
        {
            IProduct product = new IPhone();
            //Do something with the object after you get the object. 
            product.SetPrice(20.30);
            return product;
        }
    }  

}
