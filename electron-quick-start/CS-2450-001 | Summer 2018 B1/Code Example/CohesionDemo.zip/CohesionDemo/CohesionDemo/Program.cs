﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CohesionDemo
{
    class Program
    {
        //Coincidental cohesion
        int a = 12345;
        String b = "UFO Dinosour";
        
        //Communicational cohesion
        static double[] grades;
        static double[] prices;
        
        static void Main(string[] args)
        {
            //Temporal cohesion
            Initialize();
            
            //Logical cohesion
            CalcTotal(0);
            CalcTotal(1);
                        
            //Procedural cohesion
            double bookCost = TotalBookCost(prices);
            double totalGPA = TotalGPA(grades);
            double efficiency = totalGPA / bookCost;
            Console.WriteLine("The efficiency is {0}", efficiency);

            //Procedural cohesion
            Efficiency(prices, grades);
            
            //Sequential cohesion
            Efficiency(TotalGPA(grades), TotalBookCost(prices));

            //Functional cohesion
            SearchAndDisplayASCII('@');

            Console.ReadKey();
        }

        public static void Initialize()
        {
            grades = new double[] { 4, 3, 4 };
            prices = new double[] { 123.21, 234.21, 70.5 };
        }

        public static void CalcTotal(int flag)
        {
            if (flag == 0)
                Console.WriteLine("Avg. Grade is {0}", TotalGPA(grades));
            else
                Console.WriteLine("Avg. Price is {0}", TotalBookCost(prices));
        }

        public static double TotalGPA(double[] data)
        {
            double total = 0;
            for (int i = 0; i < data.Length; i++)
                total += data[i];
            return total;
        }

        public static double TotalBookCost(double[] data)
        {
            double total = 0;
            for (int i = 0; i < data.Length; i++)
                total += data[i];
            return total;
        }

        public static void Efficiency(double[] book, double[] gpa)
        {
            double bookCost = TotalBookCost(book);
            double totalGPA = TotalGPA(gpa);
            double efficiency = totalGPA/bookCost;
            Console.WriteLine("The efficiency is {0}", efficiency);
        }

        public static void Efficiency(double book, double gpa)
        {
            Console.WriteLine("The efficiency is {0}", book/gpa);
        }

        public static void SearchAndDisplayASCII(char key)
        {
            int position = 0;

            position = SearchKey(key, position);

            DisplayPosition(position);
        }

        private static int SearchKey(char key, int position)
        {
            for (int i = 0; i <= 255; i++)
            {
                if ((char)i == key)
                {
                    DisplayColor(key);
                    position = i;
                }
                Console.Write(" {0} ", (char)i);
            }
            return position;
        }

        private static void DisplayPosition(int position)
        {
            Console.WriteLine();
            Console.WriteLine("----------------------------");
            Console.WriteLine("The location is {0} at {1}", position, DateTime.Today);
        }

        private static void DisplayColor(char key)
        {
            Console.BackgroundColor = ConsoleColor.Blue;
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write("{0} ", key);
            Console.ResetColor();
        }

        //public static void SearchAndDisplayASCII(char key)
        //{
        //    int position = 0;

        //    for (int i = 0; i <= 255; i++)
        //    {
        //        if ((char)i == key)
        //        {
        //            Console.BackgroundColor = ConsoleColor.Blue;
        //            Console.ForegroundColor = ConsoleColor.Red;
        //            Console.Write("{0} ", key);
        //            Console.ResetColor();
        //            position = i;
        //        }
        //        Console.Write(" {0} ", (char)i);
        //    }

        //    Console.WriteLine();
        //    Console.WriteLine("----------------------------");
        //    Console.WriteLine("The location is {0} at {1}", position, DateTime.Today);
        //}
    }
}

