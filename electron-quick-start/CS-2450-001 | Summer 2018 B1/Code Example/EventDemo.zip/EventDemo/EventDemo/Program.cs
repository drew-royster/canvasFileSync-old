﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EventDemo
{
//Events, however, need not be used only for graphical interfaces. Events provide 
//    a generally useful way for objects to signal state changes that may be useful to 
//    clients of that object. Events are an important building block for creating 
//    classes that can be reused in a large number of different programs.

//Events are declared using delegates. 

    
    // events1.cs
    using System;
    namespace MyCollections
    {
        using System.Collections;

        // (1.1) Declaring an event   To declare an event inside a class, first a 
        // delegate type for the event must be declared, if none is already declared. 
        // A delegate type for hooking up change notifications.
        public delegate void ChangedEventHandler(object sender, EventArgs e);

        // A class that works just like ArrayList, but sends event
        // notifications whenever the list changes.
        public class ListWithChangedEvent : ArrayList
        {
            // (1.2) Next, the event itself is declared. An event that clients can 
            // use to be notified whenever the
            // elements of the list change.
            public event ChangedEventHandler Changed;

            // (2) Invoking an event: Once a class has declared an event, it can 
            // treat that event just like a field of the indicated delegate type.
            // Invoke the Changed event; called whenever list changes
            protected virtual void OnChanged(EventArgs e)
            {
                if (Changed != null)
                    Changed(this, e);
            }

            // Override some of the methods that can change the list;
            // invoke event after each
            public override int Add(object value)
            {
                int i = base.Add(value);
                OnChanged(EventArgs.Empty);
                return i;
            }

            public override void Clear()
            {
                base.Clear();
                OnChanged(EventArgs.Empty);
            }

            public override object this[int index]
            {
                set
                {
                    base[index] = value;
                    OnChanged(EventArgs.Empty);
                }
            }
        }
    }

    namespace TestEvents
    {
        using MyCollections;

        class EventListener
        {
            private ListWithChangedEvent List;

            public EventListener(ListWithChangedEvent list)
            {
                List = list;

                // (3) Hooking up to an event   From outside the class that 
                // declared it, an event looks like a field, but access to that 
                // field is very restricted. The only things that can be done 
                // are: 
                // (3.1) Compose a new delegate onto that field.
                // Add "ListChanged" to the Changed event on "List".
                

                List.Changed += new ChangedEventHandler(ListChanged);
            }

            // This will be called whenever the list changes.
            private void ListChanged(object sender, EventArgs e)
            {
                Console.WriteLine("This is called when the event fires.");
            }

            public void Detach()
            {
               
                // (3.2) Remove a delegate from a (possibly composite) field.
                // Detach the event and delete the list
                List.Changed -= new ChangedEventHandler(ListChanged);
                List = null;
            }
        }

        class Test
        {
            // Test the ListWithChangedEvent class.
            public static void Main()
            {
                // Create a new list.
                ListWithChangedEvent list = new ListWithChangedEvent();

                // Create a class that listens to the list's change event.
                EventListener listener = new EventListener(list);

                // Add and remove items from the list.
                list.Add("item 1");
                list.Clear();
                listener.Detach();

                Console.ReadKey();
            }
        }
    }

}
